Screwy Screw by msruggles on Thingiverse: https://www.thingiverse.com/thing:12526

Summary:
I found this video and wanted to make my own. One nut goes on right handed and one goes on left. All overhangs are 50deg so it should print without trouble.http://www.youtube.com/watch?v=o-fPsvqjqZI&amp;NR=1 Update:In case you missed it in the comments, the original screw and video were made by VeryWetPaint (http://www.thingiverse.com/VeryWetPaint).